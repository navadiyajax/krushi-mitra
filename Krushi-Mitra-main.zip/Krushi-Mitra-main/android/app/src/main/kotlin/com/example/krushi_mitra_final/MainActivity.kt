package com.example.krushi_mitra_final

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
