// const appname = "Pawsome Community";
// const appversion = "Version 1.0.0";
// const credits = "@abc";
// const email = "Email";
// const emailHint = "Enter your email";
// const password = "Password";
// const passwordHint = "*********";
// const ConfirmPassword = "Confirm Password ";
// const Name = "Name";
// const NameHint = "Enter your name";
// const forgetPass = "Forget Password";
// const login = "Log in";
// const logout = "Log out";
// const Signup = "Sign up";
// const createNewAccount = 'Don’t have an account?  ';
// const loginWith = "Login with";
// const privacyPolicy = "Privacy Policy";
// const loggedin = "Logged in successfully";
// const loggedout = "Logged out successfully";
// const termAndCond = "Terms and Conditions ";
// const alreadyHaveAccount = "Already have account?  ";
// const resetPass = "Reset Password";
// const newpassword = "New password";

// // home screen
// const home = "Home",
//     categories = "Categories",
//     dogType= "Category of Dog",
//     cart = "Cart",
//     account = "Account",

// oldpassword = "Old Password";



// //categories section of dog
// const labradogGroup = "Labradog Group",
//     germanShepherdGroup = "German Shepherd Group",
//     poodleGroup = "Poodle Group",
//     rottweilerGroup = "Rottweiler Group",
//     bulldogGroup = "Bulldog Group",
//     pomeranianGroup = "Pomeranian Group",
//     dobermanPinscher = "Doberman Pinscher",
//     goldenRetriever=   "Golden Retriever";

// //categories section of cat
// const shorthairedCats = "Short-haired Group",
//     longhairedCats = "Long-haired Group",
//     semilonghairedCats = "Semi-long-haired Group",
//     hairlessCats = "Hairless Group",
//     hybridCats = "Hybrid Group";

// //categories section of fish
// const freshwaterfish = "Freshwater Group",
//     saltwaterFish = "Saltwater Group",
//     coldwaterGroup = "Coldwater Group",
//     cartilaginousGroup= "Cartilaginous Group";

// //categories section of chick
// const broodGroup = "Brood Group",
//     chickClusterGroup="Chick Cluster Group";
