


// import 'package:pass_app_ultron_techonology/consts/strings.dart';

// import 'images.dart';

// const slidersList = [imgSlider2,imgSlider1, imgSlider3];
// //categories section
// const categoriesList = [
//   labradogGroup,
//   germanShepherdGroup,
//   poodleGroup,
//   rottweilerGroup,
//   bulldogGroup,
//   pomeranianGroup,
//   dobermanPinscher,
//   goldenRetriever,
// ];
// const catCategoriesList = [
//   shorthairedCats,
//   longhairedCats,
//   semilonghairedCats,
//   hairlessCats,
//   hybridCats,
// ];

// const fishCategoriesList=[
//   freshwaterfish,
//   saltwaterFish,
//   coldwaterGroup,
//   cartilaginousGroup,

// ];
// const chickCategoriesList=[
//   broodGroup,
//   chickClusterGroup,
// ];

// const categoriesImages = [
// d1,
//   d2,
//   d3,
//   d4,
//   d5,
//   d6,
//   d7,
//   d8
// ];

// const catCategoriesImages = [
//   c1,
//   c2,
//   c3,
//   c4,
//   c5,
// ];
// const fishCategoriesImages = [
//   f1,
//   f2,
//   f3,
//   f4,
// ];

// const chickCategoriesImages= [
//   ch1,
//   ch2
// ];
