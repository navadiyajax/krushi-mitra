// images

const logo1 = 'assets/logo/logo1.jpg';
