const String GEMINI_API_KEY = "AIzaSyAffBoW_HDgjss5XE5VtD5w-VzcNMjJ03I";
