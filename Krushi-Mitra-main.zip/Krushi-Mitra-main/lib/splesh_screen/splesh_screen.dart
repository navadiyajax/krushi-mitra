import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:krushi_mitra_final/consts/consts.dart';
import 'package:krushi_mitra_final/consts/firebase_constent.dart';
import 'package:krushi_mitra_final/home_screen/home.dart';
import 'package:krushi_mitra_final/splesh_screen/welcome_screen.dart';

class SpleshScreen extends StatefulWidget {
  const SpleshScreen({super.key});

  @override
  State<SpleshScreen> createState() => _SpleshScreenState();
}

class _SpleshScreenState extends State<SpleshScreen> {
  @override
  void initState() {
    super.initState();
    redirect();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: green,
      body: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image(
                  image: AssetImage(logo1),
                  width: 200,
                  height: 200,
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Krushi Mitra',
                  style: TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.bold,
                    color: whiteColor,
                    fontFamily: 'Satoshi',
                  ),
                ),
                Text(
                  'Farmer Friendly App',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: whiteColor,
                    fontFamily: 'Satoshi',
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Future<void> redirect() async {
    await Future.delayed(const Duration(seconds: 5), () {
      auth.authStateChanges().listen((User? user) {
        if (user == null && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => const WelcomeScreen(),
            ),
          );
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => const Home(),
            ),
          );
        }
      });
    });
  }
}
