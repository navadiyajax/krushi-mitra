import 'package:flutter/material.dart';
import 'package:krushi_mitra_final/auth_screen/sign_up.dart';
import 'package:krushi_mitra_final/same_code/other_option_login.dart';
import 'package:krushi_mitra_final/same_code/ourButton.dart';
import 'package:krushi_mitra_final/same_code/rounded_btn.dart';
import 'package:velocity_x/velocity_x.dart';

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  Widget build(BuildContext context) {
    var screenHeight = MediaQuery.of(context).size.height;
    // var screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/welcome.png"),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/Rectangle.png"),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            SingleChildScrollView(
              child: Column(
                // crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  (screenHeight * 0.05).heightBox,
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        ourButton(
                          onpress: () {},
                          color: Colors.white,
                          textColor: Color(0xff34A853),
                          title: 'Skip',
                          fontsize: '14.0',
                          onPress: () {},
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 41.0,
                      ),
                      Text(
                        'Welcome to',
                        style: TextStyle(
                          fontFamily: 'Satoshi',
                          fontSize: 36.0,
                          color: Color(0xffFFFFFF),
                        ),
                      ),
                      Text(
                        'KrushiMitra',
                        style: TextStyle(
                          fontFamily: 'Satoshi',
                          fontSize: 54.0,
                          color: Color(0xff0DFF4D),
                        ),
                      ),
                      SizedBox(
                        height: 150.0,
                      ),
                      Text(
                        'Make Easy Farming with fast',
                        style: TextStyle(
                          fontFamily: 'Satoshi',
                          fontSize: 18.0,
                          color: Color(0xffFFFFFF),
                        ),
                      ),
                      Text(
                        'delivery at your door.',
                        style: TextStyle(
                          fontFamily: 'Satoshi',
                          fontSize: 18.0,
                          color: Color(0xffFFFFFF),
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),

                      const Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Divider(
                                color: Color(0xFFE8ECF4),
                                thickness: 1,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: Text(
                                "sign in with",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16.0,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Divider(
                                color: Color(0xFFE8ECF4),
                                thickness: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      // AnotherOptionImg(context),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AnotherOptionLogin(
                            onpress: () {},
                            color: Colors.white,
                            textColor: Color(0xff000000),
                            title: 'Facebook',
                            logoImg: 'assets/logo/fb.png',
                            onPress: () {},
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          AnotherOptionLogin(
                            onpress: () {},
                            color: Colors.white,
                            textColor: Color(0xff000000),
                            title: 'Google ',
                            logoImg: 'assets/logo/google.png',
                            onPress: () {},
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 26.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: RoundButton(
                          title: 'Start with Email',
                          onTap: () {
                            print('Start with Email');
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: RoundButton(
                          title: 'Start with Phone',
                          onTap: () {
                            print('Start with Phone');
                          },
                        ),
                      ),
                      _welcomeScreenText(context),
                    ],
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _welcomeScreenText(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          'Already have an account?',
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
        ),
        TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => SignupScreen()));
            },
            child: const Text(
              'SignIn',
              style: TextStyle(
                fontStyle: FontStyle.normal,
                fontSize: 16.0,
                color: Colors.white,
              ),
            ))
      ],
    );
  }
}
// anotheroption
