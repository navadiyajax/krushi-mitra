import 'package:flutter/material.dart';
import 'package:flutter_zoom_drawer/flutter_zoom_drawer.dart';

class MenueSection extends StatefulWidget {
  @override
  State<MenueSection> createState() => _MenueSectionState();
}

class _MenueSectionState extends State<MenueSection> {
  MenueItem currentItem = Menue.payment;

  @override
  Widget build(BuildContext context) {
    return ZoomDrawer(
      style: DrawerStyle.defaultStyle,
      menuScreen: MenuScreen(
        currentItem: currentItem,
        onSelectedItem: (item) {
          setState(() {
            currentItem = item;
          });
          final drawer = ZoomDrawer.of(context);
          if (drawer != null) {
            drawer.toggle();
          }
        },
      ),
      mainScreen: getScreen(currentItem),
      borderRadius: 24.0,
      showShadow: true,
      angle: -12.0,
      slideWidth: MediaQuery.of(context).size.width * 0.65,
      openCurve: Curves.fastOutSlowIn,
      closeCurve: Curves.bounceIn,
      duration: const Duration(milliseconds: 500),
      overlayBlur: 0.0,
      isRtl: false,
      clipMainScreen: true,
      menuBackgroundColor: Colors.blue,
      mainScreenTapClose: true,
    );
  }

  Widget getScreen(MenueItem item) {
    switch (item.title) {
      case 'Payment':
        return const PaymentScreen();
      case 'Message':
        return const MessageScreen();
      case 'Setting':
        return const SettingScreen();
      case 'Help':
        return const HelpScreen();
      default:
        return const PaymentScreen();
    }
  }
}

class MenueItem {
  final String title;
  final IconData icon;
  MenueItem(this.title, this.icon);
}

class Menue {
  static var payment = MenueItem('Payment', Icons.payment);
  static var message = MenueItem('Message', Icons.message);
  static var setting = MenueItem('Setting', Icons.settings);
  static var help = MenueItem('Help', Icons.help);
  static var all = <MenueItem>[payment, message, setting, help];
}

class MenuScreen extends StatelessWidget {
  final MenueItem currentItem;
  final ValueChanged<MenueItem> onSelectedItem;
  const MenuScreen(
      {super.key, required this.currentItem, required this.onSelectedItem});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue,
        body: SafeArea(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Spacer(),
            ...Menue.all.map((item) => buildMenuItem(item)).toList(),
            const Spacer(
              flex: 2,
            )
          ],
        )));
  }

  Widget buildMenuItem(MenueItem item) {
    return ListTile(
      selected: currentItem == item,
      minLeadingWidth: 20,
      leading: Icon(
        item.icon,
        color: Colors.white,
      ),
      title: Text(
        item.title,
        style: const TextStyle(color: Colors.white, fontSize: 20),
      ),
      onTap: () => onSelectedItem(item),
    );
  }
}

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment'),
        leading: const MenuWidget(),
      ),
      body: const Center(child: Text('Payment Screen')),
    );
  }
}

class MessageScreen extends StatelessWidget {
  const MessageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Message'),
        leading: const MenuWidget(),
      ),
      body: const Center(child: Text('Message Screen')),
    );
  }
}

class SettingScreen extends StatelessWidget {
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Setting'),
        leading: const MenuWidget(),
      ),
      body: const Center(child: Text('Setting Screen')),
    );
  }
}

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Help'),
        leading: const MenuWidget(),
      ),
      body: const Center(child: Text('Help Screen')),
    );
  }
}

class MenuWidget extends StatelessWidget {
  const MenuWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () => ZoomDrawer.of(context)?.toggle(),
      icon: const Icon(Icons.menu),
    );
  }
}
