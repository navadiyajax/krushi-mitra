import 'package:flutter/material.dart';
import 'package:krushi_mitra_final/chat_bot/chat_bot_screen.dart';
import 'package:krushi_mitra_final/consts/colors.dart';
import 'package:krushi_mitra_final/same_code/home_screen_img.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    // var screenWidth = MediaQuery.of(context).size.width;
    // var screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      // body: HomescreenComponents(context),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // MenueSection(),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Videos',
                  fontsize: '10',
                  image: AssetImage('assets/images/truck-delivery.png'),
                ),
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Address',
                  fontsize: '10',
                  image: AssetImage('assets/images/location-1.png'),
                ),
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Corp Care',
                  fontsize: '10',
                  image: AssetImage('assets/images/stroke.png'),
                ),
              ],
            ),
            SizedBox(height: 45),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Best Offers',
                  fontsize: '10',
                  image: AssetImage('assets/images/diamond.png'),
                ),
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Soil Testing',
                  fontsize: '10',
                  image: AssetImage('assets/images/paper-pencil.png'),
                ),
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Expert Advice',
                  fontsize: '10',
                  image: AssetImage('assets/images/person-boy.png'),
                ),
              ],
            ),
            SizedBox(height: 45),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                HomeScreenDoc(
                  onpress: () {},
                  color: whiteColor,
                  textColor: Colors.black,
                  title: 'Rate Us',
                  fontsize: '10',
                  image: AssetImage('assets/images/star.png'),
                ),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                  builder: (BuildContext context) => ChatBotApp()));
        },
        tooltip: 'Increment',
        child: Image.asset('assets/images/bot.webp'),
      ),
    );
  }
}
