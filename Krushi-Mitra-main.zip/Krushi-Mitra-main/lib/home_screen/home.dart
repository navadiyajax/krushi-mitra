import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:krushi_mitra_final/auth_screen/login_page.dart';
import 'package:krushi_mitra_final/auth_screen/sign_up.dart';
import 'package:krushi_mitra_final/consts/styles.dart';
import 'package:krushi_mitra_final/controller/home_controller.dart';
import 'package:krushi_mitra_final/home_screen/home_screen.dart';
import 'package:krushi_mitra_final/splesh_screen/welcome_screen.dart';

class Home extends StatelessWidget {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Initialize Home controller
    var controller = Get.put(HomeController());

    return Scaffold(
      body: Obx(() {
        var navBody = [
          const HomePage(),
          const SignupScreen(),
          const WelcomeScreen(),
          const LoginPage(),
          const SignupScreen(),
        ];

        return Column(
          children: [
            Expanded(
              child: navBody.elementAt(controller.currentNavIndex.value),
            ),
          ],
        );
      }),
      bottomNavigationBar: Obx(() {
        var navbarItem = [
          BottomNavigationBarItem(
            icon: SizedBox(
              child: Image.asset(
                'assets/logo/home_1.png',
                height: 30.0,
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              child: Image.asset(
                'assets/logo/Cart.png',
                height: 30.0,
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              child: Image.asset(
                'assets/logo/scan_1.png',
                height: 30.0,
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              child: Image.asset(
                'assets/logo/notification.png',
                height: 30.0,
              ),
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SizedBox(
              child: Image.asset(
                'assets/logo/Group.png',
                height: 30.0,
              ),
            ),
            label: '',
          ),
        ];

        return ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
          ),
          child: BottomNavigationBar(
            currentIndex: controller.currentNavIndex.value,
            selectedItemColor: Color(0xff068042),
            selectedLabelStyle: const TextStyle(fontFamily: semibold),
            type: BottomNavigationBarType.fixed,
            backgroundColor: Color(0xffFFFFFF),
            items: navbarItem,
            onTap: (value) {
              controller.currentNavIndex.value = value;
            },
          ),
        );
      }),
    );
  }
}
