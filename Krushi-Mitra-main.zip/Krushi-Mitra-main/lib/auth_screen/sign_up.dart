// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:krushi_mitra_final/auth_screen/login_page.dart';
// import 'package:krushi_mitra_final/consts/colors.dart';
// import 'package:krushi_mitra_final/consts/firebase_constent.dart';
// import 'package:krushi_mitra_final/consts/styles.dart';
// import 'package:krushi_mitra_final/controller/auth_controller.dart';
// import 'package:krushi_mitra_final/home_screen/home_screen.dart';
// import 'package:krushi_mitra_final/same_code/custom_text_field.dart';
// import 'package:krushi_mitra_final/same_code/other_option_login.dart';
// import 'package:krushi_mitra_final/same_code/ourButton.dart';
// import 'package:velocity_x/velocity_x.dart';

// class SignupPage extends StatefulWidget {
//   const SignupPage({super.key});

//   @override
//   State<SignupPage> createState() => _SignupPageState();
// }

// class _SignupPageState extends State<SignupPage> {
//   String? _image;
//   bool? isCheck = false;
//   late MediaQueryData mq;
//   // final AuthService _authService = AuthService();
//   // final DatabaseService _dbService = DatabaseService();

//   // Text Controllers
//   var nameController = TextEditingController();
//   var emailController = TextEditingController();
//   var passwordController = TextEditingController();
//   var confirmPasswordController = TextEditingController();

//   // Visibility state for passwords
//   bool isPasswordVisible = false;
//   bool isConfirmPasswordVisible = false;

//   // Email validation
//   // ignore: non_constant_identifier_names
//   final EMAIL_VALIDATION_REGEX = RegExp(r"^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$");

//   // Password validation
//   // ignore: non_constant_identifier_names
//   final PASSWORD_VALIDATION_REGEX =
//       RegExp(r"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$");

//   // Name validation
//   // ignore: non_constant_identifier_names
//   final NAME_VALIDATION_REGEX = RegExp(r"");
//   final _formKey = GlobalKey<FormState>();
//   @override
//   Widget build(BuildContext context) {
//     var controller = Get.put(AuthController());
//     var screenHeight = MediaQuery.of(context).size.height;
//     var screenWidth = MediaQuery.of(context).size.width;

//     return Scaffold(
//       resizeToAvoidBottomInset: false,
//       body: Center(
//         child: Stack(
//           children: [
//             Container(
//               decoration: const BoxDecoration(
//                 image: DecorationImage(
//                   image: AssetImage("assets/images/authimg.png"),
//                   fit: BoxFit.fill,
//                 ),
//               ),
//             ),
//             SingleChildScrollView(
//               child: Center(
//                 child: Form(
//                   key: _formKey,
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       (screenHeight * 0.09).heightBox,
//                       10.heightBox,
//                       Padding(
//                         padding: const EdgeInsets.only(left: 30.0),
//                         child: "Sign Up"
//                             .text
//                             .fontFamily('Satoshi')
//                             .black
//                             .size(36.41)
//                             .make(),
//                       ),
//                       5.heightBox,
//                       Column(
//                         children: [
//                           customTextField(
//                             hint: 'Full name',
//                             title: 'Name',
//                             isPass: false,
//                             controller: nameController,
//                             validationRegulatorExpression:
//                                 NAME_VALIDATION_REGEX,
//                             validator: (value) {
//                               if (value == null || value.isEmpty) {
//                                 return 'Please enter your name';
//                               } else if (value != passwordController.text) {
//                                 return 'Please enter a valid name';
//                               }
//                               return null;
//                             },
//                             toggleVisibility: () {},
//                             isPasswordVisible: false,
//                             borderColor: Color(0xffFE724C),
//                           ),
//                           customTextField(
//                             hint: 'Mail',
//                             title: 'E-mail',
//                             controller: emailController,
//                             isPass: false,
//                             validationRegulatorExpression:
//                                 EMAIL_VALIDATION_REGEX,
//                             validator: (value) {
//                               if (value == null || value.isEmpty) {
//                                 return 'Please enter your email';
//                               } else if (!EMAIL_VALIDATION_REGEX
//                                   .hasMatch(value)) {
//                                 return 'Please enter a valid email';
//                               }
//                               return null;
//                             },
//                             toggleVisibility: () {},
//                             isPasswordVisible: false,
//                             borderColor: Color(0xff2372CF),
//                           ),
//                           customTextField(
//                             hint: 'Password',
//                             title: 'Password',
//                             isPass: true,
//                             controller: passwordController,
//                             validationRegulatorExpression:
//                                 PASSWORD_VALIDATION_REGEX,
//                             validator: (value) {
//                               if (value == null || value.isEmpty) {
//                                 return 'Please confirm your password';
//                               } else if (value != passwordController.text) {
//                                 return 'Password must contain at least 8 characters, including upper/lower case and numbers';
//                               }
//                               return null;
//                             },
//                             toggleVisibility: () {
//                               setState(() {
//                                 isPasswordVisible = !isPasswordVisible;
//                               });
//                             },
//                             isPasswordVisible: isPasswordVisible,
//                             borderColor: Color(0xff34A853),
//                           ),
//                           customTextField(
//                             hint: 'Conform Password',
//                             title: 'Conform Password',
//                             isPass: true,
//                             controller: confirmPasswordController,
//                             validationRegulatorExpression:
//                                 PASSWORD_VALIDATION_REGEX,
//                             validator: (value) {
//                               if (value == null || value.isEmpty) {
//                                 return 'Please confirm your password';
//                               } else if (value != passwordController.text) {
//                                 return 'Passwords do not match';
//                               }
//                               return null;
//                             },
//                             toggleVisibility: () {
//                               setState(() {
//                                 isConfirmPasswordVisible =
//                                     !isConfirmPasswordVisible;
//                               });
//                             },
//                             isPasswordVisible: isConfirmPasswordVisible,
//                             borderColor: Color(0xff34A853),
//                           ),
//                           Row(
//                             children: [
//                               Checkbox(
//                                 activeColor: const Color(0xFF34A853),
//                                 checkColor: whiteColor,
//                                 value: isCheck,
//                                 onChanged: (newValue) {
//                                   setState(() {
//                                     isCheck = newValue;
//                                   });
//                                 },
//                               ),
//                               5.widthBox,
//                               Expanded(
//                                 child: RichText(
//                                   text: const TextSpan(
//                                     children: [
//                                       TextSpan(
//                                         text: "I agree to the",
//                                         style: TextStyle(
//                                           fontFamily: regular,
//                                           color: fontGrey,
//                                         ),
//                                       ),
//                                       TextSpan(
//                                         text: 'Terms and Conditions ',
//                                         style: TextStyle(
//                                           fontFamily: regular,
//                                           color: Colors.red,
//                                         ),
//                                       ),
//                                       TextSpan(
//                                         text: "&",
//                                         style: TextStyle(
//                                           fontFamily: regular,
//                                           color: fontGrey,
//                                         ),
//                                       ),
//                                       TextSpan(
//                                         text: ' Privacy Policy',
//                                         style: TextStyle(
//                                           fontFamily: regular,
//                                           color: Colors.red,
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                           SizedBox(
//                             height: 33.0,
//                           ),
//                           ourButton(
//                             color: isCheck == true ? green : lightGrey,
//                             title: 'SIGN UP',
//                             textColor: whiteColor,
//                             onpress: () async {
//                               if (isCheck == true) {
//                                 if (_formKey.currentState!.validate()) {
//                                   controller.isloading(true);
//                                   try {
//                                     await controller.SignupMethod(
//                                       context: context,
//                                       email: emailController.text,
//                                       password: passwordController.text,
//                                     ).then((value) {
//                                       return controller.storeUserData(
//                                         email: emailController.text,
//                                         password: passwordController.text,
//                                         Name: nameController.text,
//                                       );
//                                     }).then((value) {
//                                       VxToast.show(context, msg: 'loggedin');
//                                       if (mounted) {
//                                         Get.offAll(() => const HomePage());
//                                       }
//                                     });
//                                   } catch (e) {
//                                     auth.signOut();
//                                     VxToast.show(context, msg: e.toString());
//                                     controller.isloading(false);
//                                   }
//                                 }
//                               } else {
//                                 VxToast.show(context,
//                                     msg:
//                                         'Please accept the terms and conditions');
//                               }
//                             },
//                             fontsize: '18.0',
//                             onPress: () {},
//                           ).box.width(screenWidth - 150).height(60).make(),
//                           SizedBox(
//                             height: 15.0,
//                           ),
//                           _signUpScreenText(context),
//                           SizedBox(
//                             height: 15.0,
//                           ),
//                           const Padding(
//                             padding: EdgeInsets.symmetric(
//                                 horizontal: 10, vertical: 0),
//                             child: Row(
//                               children: [
//                                 Expanded(
//                                   child: Divider(
//                                     color: Color(0xFF5B5B5E),
//                                     thickness: 1,
//                                   ),
//                                 ),
//                                 Padding(
//                                   padding: EdgeInsets.symmetric(horizontal: 10),
//                                   child: Text(
//                                     "sign in with",
//                                     style: TextStyle(
//                                       color: Color(0xff5B5B5E),
//                                       fontSize: 16.0,
//                                     ),
//                                   ),
//                                 ),
//                                 Expanded(
//                                   child: Divider(
//                                     color: Color(0xff5B5B5E),
//                                     thickness: 1,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                           SizedBox(
//                             height: 15.0,
//                           ),
//                           Row(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             children: [
//                               AnotherOptionLogin(
//                                 onpress: () {},
//                                 color: Colors.white,
//                                 textColor: Color(0xff000000),
//                                 title: 'Facebook',
//                                 logoImg: 'assets/logo/fb.png',
//                                 onPress: () {},
//                               ),
//                               SizedBox(
//                                 width: 10.0,
//                               ),
//                               AnotherOptionLogin(
//                                 onpress: () {},
//                                 color: Colors.white,
//                                 textColor: Color(0xff000000),
//                                 title: 'Google',
//                                 logoImg: 'assets/logo/google.png',
//                                 onPress: () {},
//                               ),
//                             ],
//                           ),
//                         ],
//                       )
//                           .box
//                           .rounded
//                           .padding(const EdgeInsets.all(16))
//                           .width(screenWidth)
//                           .make(),
//                       (screenHeight * 0.08).heightBox,
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//             Obx(() {
//               if (controller.isloading.value) {
//                 return Container(
//                   color: Colors.black.withOpacity(0.5),
//                   child: const Center(
//                     child: CircularProgressIndicator(
//                       valueColor: AlwaysStoppedAnimation(green),
//                     ),
//                   ),
//                 );
//               } else {
//                 return Container();
//               }
//             }),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _signUpScreenText(BuildContext context) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         const Text(
//           'Already have an account?',
//           style: TextStyle(
//               // fontWeight: FontWeight.bold,
//               fontSize: 14.0,
//               color: Color(0xff5B5B5E)),
//         ),
//         TextButton(
//             onPressed: () {
//               Navigator.pushReplacement(
//                   context,
//                   MaterialPageRoute(
//                       builder: (BuildContext context) => LoginPage()));
//             },
//             child: const Text(
//               'Login',
//               style: TextStyle(
//                 fontStyle: FontStyle.normal,
//                 fontSize: 14.0,
//                 color: green,
//               ),
//             ))
//       ],
//     );
//   }
// }

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:krushi_mitra_final/auth_screen/login_page.dart';
import 'package:krushi_mitra_final/consts/colors.dart';
import 'package:krushi_mitra_final/consts/firebase_constent.dart';
import 'package:krushi_mitra_final/consts/styles.dart';
import 'package:krushi_mitra_final/controller/auth_controller.dart';
import 'package:krushi_mitra_final/home_screen/home.dart';
import 'package:krushi_mitra_final/same_code/custom_text_field.dart';
import 'package:krushi_mitra_final/same_code/other_option_login.dart';
import 'package:krushi_mitra_final/same_code/ourButton.dart';
import 'package:velocity_x/velocity_x.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  String? _image;
  bool? isCheck = false;
  var controller = Get.put(AuthController());

  // Text Controllers
  var nameController = TextEditingController();
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();

  // Visibility state for passwords
  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;

  // Email validation
  // ignore: non_constant_identifier_names
  final EMAIL_VALIDATION_REGEX = RegExp(r"^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$");

  // Password validation
  // ignore: non_constant_identifier_names
  final PASSWORD_VALIDATION_REGEX =
      RegExp(r"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$");

  // Name validation
  // ignore: non_constant_identifier_names
  final NAME_VALIDATION_REGEX = RegExp(r"\b([A-ZÀ-ÿ][-,a-z. ']+[ ]*)+");

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    var screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/authimg.png"),
                fit: BoxFit.fill,
              ),
            ),
          ),
          SingleChildScrollView(
            child: Center(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    (screenHeight * 0.09).heightBox,
                    15.heightBox,
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0),
                      child: "SIGN UP"
                          .text
                          .fontFamily('Satoshi')
                          .black
                          .size(36.41)
                          .make(),
                    ),
                    15.heightBox,
                    Column(
                      children: [
                        customTextField(
                          hint: 'Enter your full name',
                          title: 'Full name',
                          controller: nameController,
                          isPass: false,
                          validationRegulatorExpression: NAME_VALIDATION_REGEX,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your name';
                            } else if (!NAME_VALIDATION_REGEX.hasMatch(value)) {
                              return 'Please enter a valid name';
                            }
                            return null;
                          },
                          toggleVisibility: () {},
                          isPasswordVisible: false,
                          borderColor: Color(0xffFE724C),
                        ),
                        customTextField(
                          hint: 'Enter your email',
                          title: 'Email',
                          controller: emailController,
                          isPass: false,
                          validationRegulatorExpression: EMAIL_VALIDATION_REGEX,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your email';
                            } else if (!EMAIL_VALIDATION_REGEX
                                .hasMatch(value)) {
                              return 'Please enter a valid email';
                            }
                            return null;
                          },
                          toggleVisibility: () {},
                          isPasswordVisible: false,
                          borderColor: Color(0xff2372CF),
                        ),
                        customTextField(
                          hint: 'Enter your password',
                          title: 'Password',
                          controller: passwordController,
                          isPass: true,
                          validationRegulatorExpression:
                              PASSWORD_VALIDATION_REGEX,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your password';
                            } else if (!PASSWORD_VALIDATION_REGEX
                                .hasMatch(value)) {
                              return 'Password must contain at least 8 characters, including upper/lower case and numbers';
                            }
                            return null;
                          },
                          toggleVisibility: () {
                            setState(() {
                              isPasswordVisible = !isPasswordVisible;
                            });
                          },
                          isPasswordVisible: isPasswordVisible,
                          borderColor: Color(0xff34A853),
                        ),
                        customTextField(
                          hint: 'Enter your password',
                          title: 'Confirm Password',
                          controller: confirmPasswordController,
                          isPass: true,
                          validationRegulatorExpression:
                              PASSWORD_VALIDATION_REGEX,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please confirm your password';
                            } else if (value != passwordController.text) {
                              return 'Passwords do not match';
                            }
                            return null;
                          },
                          toggleVisibility: () {
                            setState(() {
                              isConfirmPasswordVisible =
                                  !isConfirmPasswordVisible;
                            });
                          },
                          isPasswordVisible: isConfirmPasswordVisible,
                          borderColor: Color(0xff34A853),
                        ),
                        Row(
                          children: [
                            Checkbox(
                              activeColor: const Color(0xFF34A853),
                              checkColor: whiteColor,
                              value: isCheck,
                              onChanged: (newValue) {
                                setState(() {
                                  isCheck = newValue;
                                });
                              },
                            ),
                            5.widthBox,
                            Expanded(
                              child: RichText(
                                text: const TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "I agree to the ",
                                      style: TextStyle(
                                        fontFamily: regular,
                                        color: fontGrey,
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'Terms and Conditions ',
                                      style: TextStyle(
                                        fontFamily: regular,
                                        color: Colors.red,
                                      ),
                                    ),
                                    TextSpan(
                                      text: "&",
                                      style: TextStyle(
                                        fontFamily: regular,
                                        color: fontGrey,
                                      ),
                                    ),
                                    TextSpan(
                                      text: ' Privacy Policy',
                                      style: TextStyle(
                                        fontFamily: regular,
                                        color: Colors.red,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        5.heightBox,
                        ourButton(
                          color: isCheck == true
                              ? const Color(0xFF34A853)
                              : lightGrey,
                          title: 'Sign up',
                          textColor: whiteColor,
                          onpress: () async {
                            if (isCheck == true) {
                              if (_formKey.currentState!.validate()) {
                                controller.isloading(true);
                                try {
                                  await controller.SignupMethod(
                                    context: context,
                                    email: emailController.text,
                                    password: passwordController.text,
                                  ).then((value) {
                                    return controller.storeUserData(
                                      email: emailController.text,
                                      password: passwordController.text,
                                      Name: nameController.text,
                                    );
                                  }).then((value) {
                                    VxToast.show(context, msg: 'loggedin');
                                    if (mounted) {
                                      Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  Home()));
                                    }
                                  });
                                } catch (e) {
                                  auth.signOut();
                                  VxToast.show(context, msg: e.toString());
                                  controller.isloading(false);
                                }
                              }
                            } else {
                              VxToast.show(context,
                                  msg:
                                      'Please accept the terms and conditions');
                            }
                          },
                          onPress: () {},
                          fontsize: '16.0',
                        ).box.width(screenWidth - 150).make(),
                        10.heightBox,
                        _signUpScreenText(context),
                        10.heightBox,
                        const Padding(
                          padding:
                              EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                          child: Row(
                            children: [
                              Expanded(
                                child: Divider(
                                  color: const Color(0xFF5B5B5E),
                                  thickness: 1,
                                ),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 10),
                                child: Text(
                                  "sign in with",
                                  style: TextStyle(
                                    color: const Color(0xff5B5B5E),
                                    fontSize: 16.0,
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Divider(
                                  color: const Color(0xff5B5B5E),
                                  thickness: 1,
                                ),
                              ),
                            ],
                          ),
                        ),
                        10.heightBox,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            AnotherOptionLogin(
                              onpress: () {},
                              color: Colors.white,
                              textColor: const Color(0xff000000),
                              title: 'Facebook',
                              logoImg: 'assets/logo/fb.png',
                              onPress: () {},
                            ),
                            10.widthBox,
                            AnotherOptionLogin(
                              onpress: () {},
                              color: Colors.white,
                              textColor: const Color(0xff000000),
                              title: 'Google',
                              logoImg: 'assets/logo/google.png',
                              onPress: () {},
                            ),
                          ],
                        ),
                      ],
                    )
                        .box
                        .padding(const EdgeInsets.all(16))
                        .width(screenWidth - 30)
                        .make(),
                  ],
                ),
              ),
            ),
          ),
          Obx(() {
            if (controller.isloading.value) {
              return Stack(
                children: [
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 5.0, sigmaY: 5.0),
                    child: Container(
                      color: Colors.black.withOpacity(0.5),
                      width: double.infinity,
                      height: double.infinity,
                    ),
                  ),
                  const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(green),
                    ),
                  ),
                ],
              );
            } else {
              return const SizedBox.shrink();
            }
          }),
        ],
      ),
    );
  }

  Widget _signUpScreenText(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          'Already have an account?',
          style: TextStyle(
              // fontWeight: FontWeight.bold,
              fontSize: 14.0,
              color: Color(0xff5B5B5E)),
        ),
        TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => LoginPage()));
            },
            child: const Text(
              'Login',
              style: TextStyle(
                fontStyle: FontStyle.normal,
                fontSize: 14.0,
                color: green,
              ),
            ))
      ],
    );
  }
}
