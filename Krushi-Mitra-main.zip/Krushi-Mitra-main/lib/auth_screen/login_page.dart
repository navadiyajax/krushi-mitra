import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:krushi_mitra_final/auth_screen/sign_up.dart';
import 'package:krushi_mitra_final/consts/colors.dart';
import 'package:krushi_mitra_final/controller/auth_controller.dart';
import 'package:krushi_mitra_final/home_screen/home.dart';
import 'package:krushi_mitra_final/same_code/custom_text_field.dart';
import 'package:krushi_mitra_final/same_code/other_option_login.dart';
import 'package:krushi_mitra_final/same_code/ourButton.dart';
import 'package:velocity_x/velocity_x.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  // String? _image;
  bool? isCheck = false;
  late MediaQueryData mq;
  // final AuthService _authService = AuthService();
  // final DatabaseService _dbService = DatabaseService();

  // Text Controllers
  var nameController = TextEditingController();
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var confirmPasswordController = TextEditingController();

  // Visibility state for passwords
  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;

  // Email validation
  // ignore: non_constant_identifier_names
  final RegExp EMAIL_VALIDATION_REGEX =
      RegExp(r"^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$");

  // Password validation
  // ignore: non_constant_identifier_names
  final RegExp PASSWORD_VALIDATION_REGEX =
      RegExp(r"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$");

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(AuthController());
    var screenHeight = MediaQuery.of(context).size.height;
    var screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/authimg.png"),
                  fit: BoxFit.fill,
                ),
              ),
            ),
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  (screenHeight * 0.13).heightBox,
                  10.heightBox,
                  Padding(
                    padding: const EdgeInsets.only(left: 30.0),
                    child: "Login"
                        .text
                        .fontFamily('Satoshi')
                        .black
                        .size(36.41)
                        .make(),
                  ),
                  5.heightBox,
                  Column(
                    children: [
                      customTextField(
                        hint: 'e-mail',
                        title: 'E-mail',
                        controller: emailController,
                        isPass: false,
                        validationRegulatorExpression: EMAIL_VALIDATION_REGEX,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your email';
                          } else if (!EMAIL_VALIDATION_REGEX.hasMatch(value)) {
                            return 'Please enter a valid email';
                          }
                          return null;
                        },
                        toggleVisibility: () {},
                        isPasswordVisible: false,
                        borderColor: Color(0xff2372CF),
                      ),
                      customTextField(
                        hint: 'Password',
                        title: 'Password',
                        isPass: true,
                        controller: controller.passwordController,
                        validationRegulatorExpression:
                            PASSWORD_VALIDATION_REGEX,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please confirm your password';
                          } else if (value != passwordController.text) {
                            return 'Passwords do not match';
                          }
                          return null;
                        },
                        toggleVisibility: () {
                          setState(() {
                            isConfirmPasswordVisible =
                                !isConfirmPasswordVisible;
                          });
                        },
                        isPasswordVisible: isConfirmPasswordVisible,
                        borderColor: Color(0xff34A853),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () {
                            // Get.to(() => const ForgotPasswordScreen());
                          },
                          style: ButtonStyle(
                            foregroundColor: MaterialStateProperty.all<Color>(
                                const Color(0xFF34A853)), // Change color here
                          ),
                          child: const Text('Forgot Password'),
                        ),
                      ),
                      SizedBox(
                        height: 33.0,
                      ),
                      controller.isloading.value
                          ? Container() // Placeholder for loading indicator
                          : ourButton(
                              color: const Color(0xFFCA7867),
                              title: 'login',
                              textColor: whiteColor,
                              onpress: () async {
                                controller.isloading(true);
                                await controller
                                    .loginMethod(context: context)
                                    .then((value) {
                                  if (value != null) {
                                    VxToast.show(context, msg: 'loggedin');
                                    Get.offAll(() => const Home());
                                  } else {
                                    controller.isloading(false);
                                  }
                                });
                              },
                              onPress: () {},
                              fontsize: '16.0',
                            ).box.width(screenWidth - 50).make(),
                      SizedBox(
                        height: 15.0,
                      ),
                      _loginScreenText(context),
                      SizedBox(
                        height: 15.0,
                      ),
                      const Padding(
                        padding:
                            EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                        child: Row(
                          children: [
                            Expanded(
                              child: Divider(
                                color: Color(0xFF5B5B5E),
                                thickness: 1,
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(horizontal: 10),
                              child: Text(
                                "sign in with",
                                style: TextStyle(
                                  color: Color(0xff5B5B5E),
                                  fontSize: 16.0,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Divider(
                                color: Color(0xff5B5B5E),
                                thickness: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 15.0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AnotherOptionLogin(
                            onpress: () {},
                            color: Colors.white,
                            textColor: Color(0xff000000),
                            title: 'Facebook',
                            logoImg: 'assets/logo/fb.png',
                            onPress: () {},
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          AnotherOptionLogin(
                            onpress: () {
                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          Home()));
                            },
                            color: Colors.white,
                            textColor: Color(0xff000000),
                            title: 'Google',
                            logoImg: 'assets/logo/google.png',
                            onPress: () {},
                          ),
                        ],
                      ),
                    ],
                  )
                      .box
                      .rounded
                      .padding(const EdgeInsets.all(16))
                      .width(screenWidth)
                      .make(),
                  (screenHeight * 0.08).heightBox,
                ],
              ),
            ),
            Obx(() {
              if (controller.isloading.value) {
                return Container(
                  color: Colors.black.withOpacity(0.5),
                  child: const Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(green),
                    ),
                  ),
                );
              } else {
                return Container();
              }
            }),
          ],
        ),
      ),
    );
  }

  Widget _loginScreenText(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text(
          'Already have an account?',
          style: TextStyle(
              // fontWeight: FontWeight.bold,
              fontSize: 14.0,
              color: Color(0xff5B5B5E)),
        ),
        TextButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => SignupScreen()));
            },
            child: const Text(
              'Sign Up',
              style: TextStyle(
                fontStyle: FontStyle.normal,
                fontSize: 14.0,
                color: green,
              ),
            ))
      ],
    );
  }
}
