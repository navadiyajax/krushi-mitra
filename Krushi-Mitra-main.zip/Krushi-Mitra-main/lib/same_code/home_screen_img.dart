import 'package:flutter/material.dart';
import 'package:krushi_mitra_final/consts/styles.dart';

Widget HomeScreenDoc({
  required VoidCallback onpress,
  required Color color,
  required Color textColor,
  required String title,
  required String fontsize,
  required ImageProvider image, // Add the required image parameter
}) {
  return Container(
    decoration: BoxDecoration(
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.1),
          spreadRadius: 1,
          blurRadius: 10,
          offset: Offset(0, 1), // changes position of shadow
        ),
      ],
      borderRadius: BorderRadius.circular(28.5),
    ),
    child: ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: const EdgeInsets.all(12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14.02), // rounded corners
        ),
      ),
      onPressed: onpress,
      child: Container(
        height: 79.39,
        width: 79.39,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          // Customize the height of the button
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image(
                  image: image,
                  height: 30, // Customize the height of the image
                  width: 30, // Customize the width of the image
                ),
                SizedBox(height: 12), // Space between image and text
                Text(
                  title,
                  strutStyle: StrutStyle(fontFamily: 'Satoshi'),
                  style: TextStyle(
                    color: textColor,
                    fontFamily: bold,
                    fontSize: double.parse(fontsize),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    ),
  );
}
