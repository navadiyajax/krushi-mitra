// import 'package:flutter/material.dart';

// class RoundButton extends StatelessWidget {
//   final String title;
//   final VoidCallback onTap;
//   final bool loading;

//   const RoundButton({
//     Key? key,
//     required this.title,
//     required this.onTap,
//     this.loading = false,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//       onTap: onTap,
//       child: Container(
//         height: 50,
//         decoration: BoxDecoration(
//           color: Colors.transparent,
//           // color: Color.fromARGB(0, 244, 0, 0),
//           borderRadius: BorderRadius.circular(20),
//           border: Border.all(
//             color: const Color(0xffffffff),
//             width: 1,
//           ),
//         ),
//         child: Center(
//           child: loading
//               ? const CircularProgressIndicator(
//                   strokeWidth: 3,
//                   color: Colors.white,
//                 )
//               : Text(
//                   title,
//                   style: const TextStyle(
//                     color: Colors.white,
//                   ),
//                 ),
//         ),
//       ),
//     );
//   }
// }

import 'dart:ui'; // Needed for ImageFilter

import 'package:flutter/material.dart';

class RoundButton extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  final bool loading;

  const RoundButton({
    Key? key,
    required this.title,
    required this.onTap,
    this.loading = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Stack(
        children: [
          Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: const Color(0xffffffff),
                width: 1,
              ),
            ),
          ),
          Positioned.fill(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
                child: Container(
                  color: Colors.transparent,
                  child: Center(
                    child: loading
                        ? const CircularProgressIndicator(
                            strokeWidth: 3,
                            color: Colors.white,
                          )
                        : Text(
                            title,
                            style: const TextStyle(
                              color: Colors.white,
                            ),
                          ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
