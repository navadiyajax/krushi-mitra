import 'package:flutter/cupertino.dart';

import 'package:velocity_x/velocity_x.dart';

Widget AnotherOptionImg(BuildContext context) {
  double screenWidth = MediaQuery.of(context).size.width;

  // Calculate size based on screen width, e.g., 10% of screen width
  double size = screenWidth * 0.2; // Adjust this factor as needed

  return Image.asset('assets/logo/anotherOption')
      .box
      .size(size, size)
      .padding(const EdgeInsets.all(8))
      .make();
}
