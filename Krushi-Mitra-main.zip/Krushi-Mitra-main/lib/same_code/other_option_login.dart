import 'package:flutter/material.dart';
import 'package:krushi_mitra_final/consts/styles.dart';

Widget AnotherOptionLogin(
    {required onpress,
    required Color color,
    required Color textColor,
    required String title,
    required String logoImg,
    required Null Function() onPress}) {
  return ElevatedButton(
    style: ElevatedButton.styleFrom(
      backgroundColor: color,
      padding: const EdgeInsets.all(12),
    ),
    onPressed: onpress,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset(logoImg),
        SizedBox(width: 8.0),
        Text(
          title,
          style: TextStyle(
            color: textColor,
            fontFamily: bold,
          ),
        ),
      ],
    ),
  );
}
