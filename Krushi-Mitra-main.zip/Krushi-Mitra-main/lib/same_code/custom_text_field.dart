// import 'package:flutter/material.dart';
// import 'package:krushi_mitra_final/consts/colors.dart';

// Widget customTextField({
//   required String hint,
//   required String title,
//   required TextEditingController controller,
//   required bool isPass,
//   required RegExp validationRegulatorExpression,
//   required FormFieldValidator<String> validator,
//   required VoidCallback toggleVisibility,
//   required bool isPasswordVisible,
// }) {
//   return Column(
//     crossAxisAlignment: CrossAxisAlignment.start,
//     children: [
//       // if (title != null) title.text.color(Colors.black).fontFamily(semibold).size(16).make(),
// //       5.heightBox,
//       Padding(
//         padding: const EdgeInsets.all(10.0),
//         child: TextFormField(
//           controller: controller,
//           obscureText: isPass && !isPasswordVisible,
//           decoration: InputDecoration(
//             labelText: title,
//             hintText: hint,
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(10.0),
//               borderSide: const BorderSide(),
//             ),
//             focusedBorder: OutlineInputBorder(
//               borderSide: const BorderSide(
//                 color: darkFontGrey,
//               ),
//               borderRadius: BorderRadius.circular(10.0),
//             ),
//             suffixIcon: isPass
//                 ? IconButton(
//                     icon: Icon(
//                       isPasswordVisible
//                           ? Icons.visibility
//                           : Icons.visibility_off,
//                       color: fontGrey,
//                     ),
//                     onPressed: toggleVisibility,
//                   )
//                 : null,
//           ),
//           validator: validator,
//         ),
//       ),
//     ],
//   );
// }

import 'package:flutter/material.dart';
import 'package:krushi_mitra_final/consts/colors.dart';

Widget customTextField({
  required String hint,
  required String title,
  required TextEditingController controller,
  required bool isPass,
  required RegExp validationRegulatorExpression,
  required FormFieldValidator<String> validator,
  required VoidCallback toggleVisibility,
  required bool isPasswordVisible,
  required Color borderColor,
}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.all(10.0),
        child: TextFormField(
          controller: controller,
          obscureText: isPass && !isPasswordVisible,
          decoration: InputDecoration(
            labelText: title,
            hintText: hint,
            focusColor: borderColor,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.0),
              borderSide: BorderSide(
                color: borderColor,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: borderColor,
              ),
              borderRadius: BorderRadius.circular(10.0),
            ),
            suffixIcon: isPass
                ? IconButton(
                    icon: Icon(
                      isPasswordVisible
                          ? Icons.visibility
                          : Icons.visibility_off,
                      color: fontGrey,
                    ),
                    onPressed: toggleVisibility,
                  )
                : null,
          ),
          validator: validator,
        ),
      ),
    ],
  );
}
